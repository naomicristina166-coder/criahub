/* CriaHub — versão própria (criahub.app.br)
   Liga o app ao Supabase: login, dados de cada creator, cotações e instalação.
   Os dados ficam protegidos por RLS: cada pessoa só lê e grava o que é dela. */
(() => {
  const cfg = window.CRIAHUB_CONFIG || {};
  window.CRIAHUB_STANDALONE = true;
  if (!window.supabase || !cfg.url || !cfg.key) { document.addEventListener('DOMContentLoaded', () => { document.body.insertAdjacentHTML('afterbegin', '<div style="padding:20px;background:#C2312F;color:#fff;font:600 15px system-ui">Configuração do CriaHub incompleta (config.js) ou sem internet.</div>'); }); return; }
  const sb = window.supabase.createClient(cfg.url, cfg.key, { auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true } });
  window.criahubSupabase = sb;
  let session = null, readyRes; const ready = new Promise(r => { readyRes = r; });
  const uid = () => session.user.id;

  /* ---------- tela de login ---------- */
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  let mode = 'entrar', msg = '', err = '', busy = false;
  const css = `.auth{position:fixed;inset:0;z-index:200;background:#420725;color:#fff;display:flex;align-items:center;justify-content:center;padding:24px;overflow:auto;font-family:var(--body,system-ui)}
  .auth .box{width:100%;max-width:380px;display:flex;flex-direction:column;gap:14px}
  .auth .au-lg{font-family:var(--display,system-ui);font-weight:800;font-size:56px;letter-spacing:-.035em;line-height:.9;text-align:center;margin-bottom:6px}
  .auth .au-lg .a{color:#F4C9D8;display:block}.auth .au-lg .b{color:#fff;display:block}
  .auth .tg{text-align:center;color:rgb(255 255 255 / .75);font-weight:600;margin-bottom:8px}
  .auth .tabs2{display:grid;grid-template-columns:1fr 1fr;background:rgb(255 255 255 / .1);border-radius:12px;padding:4px}
  .auth .tabs2 button{border:0;background:none;color:#fff;font-weight:700;padding:9px;border-radius:9px;font:inherit;font-weight:700;cursor:pointer}
  .auth .tabs2 button[aria-pressed=true]{background:#fff;color:#420725}
  .auth label{font-size:13px;font-weight:700;display:flex;flex-direction:column;gap:5px}
  .auth input{border:0;border-radius:11px;padding:12px;font:inherit;font-size:16px;color:#22141A;background:#fff;min-height:46px}
  .auth .go{border:0;border-radius:12px;background:#FF5C8A;color:#fff;font:inherit;font-weight:800;font-size:16px;padding:13px;cursor:pointer}
  .auth .go[disabled]{opacity:.6}
  .auth .lnk{background:none;border:0;color:#F4C9D8;font:inherit;font-weight:700;cursor:pointer;padding:4px;align-self:center}
  .auth .m{background:rgb(255 255 255 / .12);border-radius:12px;padding:10px 12px;font-size:14px}
  .auth .e{background:#C2312F;border-radius:12px;padding:10px 12px;font-size:14px;font-weight:600}
  .auth .sm{font-size:12.5px;color:rgb(255 255 255 / .7);text-align:center}`;
  function renderAuth() {
    let el = document.getElementById('auth');
    if (!el) { const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st); el = document.createElement('div'); el.id = 'auth'; el.className = 'auth'; document.body.appendChild(el); }
    const t = { entrar: 'Entrar', criar: 'Criar conta', esqueci: 'Recuperar senha', nova: 'Nova senha' }[mode];
    el.innerHTML = `<form class="box" id="authf" novalidate>
      <div class="au-lg" aria-label="criahub"><span class="a">cria</span><span class="b">hub</span></div><div class="tg">quem cria, se organiza.</div>
      ${mode === 'entrar' || mode === 'criar' ? `<div class="tabs2"><button type="button" data-am="entrar" aria-pressed="${mode === 'entrar'}">Entrar</button><button type="button" data-am="criar" aria-pressed="${mode === 'criar'}">Criar conta</button></div>` : `<b style="font-size:20px;text-align:center">${t}</b>`}
      ${err ? `<div class="e">${esc(err)}</div>` : ''}${msg ? `<div class="m">${esc(msg)}</div>` : ''}
      ${mode === 'criar' ? '<label>Seu nome<input name="name" autocomplete="given-name" required></label>' : ''}
      ${mode !== 'nova' ? '<label>E-mail<input name="email" type="email" autocomplete="email" inputmode="email" required></label>' : ''}
      ${mode === 'entrar' || mode === 'criar' || mode === 'nova' ? `<label>${mode === 'nova' ? 'Nova senha' : 'Senha'}<input name="pass" type="password" autocomplete="${mode === 'entrar' ? 'current-password' : 'new-password'}" minlength="6" required></label>` : ''}
      <button class="go" ${busy ? 'disabled' : ''}>${busy ? 'Aguarde…' : mode === 'esqueci' ? 'Enviar link' : mode === 'nova' ? 'Salvar senha' : t}</button>
      ${mode === 'entrar' ? '<button type="button" class="lnk" data-am="esqueci">Esqueci minha senha</button>' : mode === 'esqueci' ? '<button type="button" class="lnk" data-am="entrar">Voltar</button>' : ''}
      ${mode === 'criar' ? '<div class="sm">A senha precisa ter pelo menos 6 caracteres.</div>' : ''}
    </form>`;
  }
  const ptErr = e => { const m = String(e?.message || e || ''); if (/invalid login/i.test(m)) return 'E-mail ou senha incorretos.'; if (/email not confirmed/i.test(m)) return 'Confirme seu e-mail pelo link que enviamos antes de entrar.'; if (/already registered|already been registered/i.test(m)) return 'Esse e-mail já tem conta. Toque em Entrar.'; if (/password/i.test(m) && /6/.test(m)) return 'A senha precisa ter pelo menos 6 caracteres.'; if (/rate|too many/i.test(m)) return 'Muitas tentativas. Espere alguns minutos e tente de novo.'; if (/fetch|network/i.test(m)) return 'Sem conexão. Confira sua internet.'; return 'Não deu certo: ' + m; };
  document.addEventListener('click', e => { const b = e.target.closest('[data-am]'); if (!b) return; mode = b.dataset.am; err = ''; msg = ''; renderAuth(); });
  document.addEventListener('submit', async e => {
    if (e.target.id !== 'authf') return; e.preventDefault(); e.stopImmediatePropagation();
    const f = e.target, v = n => (f.elements[n]?.value || '').trim(); err = ''; msg = '';
    if (mode !== 'nova' && !/^\S+@\S+\.\S+$/.test(v('email'))) { err = 'Digite um e-mail válido.'; return renderAuth(); }
    if ((mode === 'entrar' || mode === 'criar' || mode === 'nova') && v('pass').length < 6) { err = 'A senha precisa ter pelo menos 6 caracteres.'; return renderAuth(); }
    busy = true; renderAuth();
    try {
      if (mode === 'entrar') { const { error } = await sb.auth.signInWithPassword({ email: v('email'), password: f.elements.pass.value }); if (error) throw error; }
      else if (mode === 'criar') { try { localStorage.setItem('criahub:pendingName', v('name')); } catch (_) {} const { data, error } = await sb.auth.signUp({ email: v('email'), password: f.elements.pass.value, options: { data: { name: v('name') }, emailRedirectTo: location.origin + location.pathname } }); if (error) throw error; if (!data.session) { mode = 'entrar'; msg = 'Conta criada! Enviamos um link de confirmação para o seu e-mail. Depois de confirmar, entre aqui.'; } }
      else if (mode === 'esqueci') { const { error } = await sb.auth.resetPasswordForEmail(v('email'), { redirectTo: location.origin + location.pathname }); if (error) throw error; mode = 'entrar'; msg = 'Se esse e-mail tiver conta, enviamos um link para criar uma nova senha.'; }
      else if (mode === 'nova') { const { error } = await sb.auth.updateUser({ password: f.elements.pass.value }); if (error) throw error; document.getElementById('auth')?.remove(); if (session) readyRes(); }
    } catch (x) { err = ptErr(x); }
    busy = false; if (document.getElementById('auth')) renderAuth();
  }, true);

  sb.auth.onAuthStateChange((ev, s) => {
    if (ev === 'PASSWORD_RECOVERY') { session = s; mode = 'nova'; err = ''; msg = ''; renderAuth(); return; }
    if (ev === 'SIGNED_OUT') { location.reload(); return; }
    if (s && !session) { session = s; if (mode !== 'nova') { document.getElementById('auth')?.remove(); readyRes(); } }
  });
  sb.auth.getSession().then(({ data }) => {
    if (data.session) { if (!session) { session = data.session; } if (mode !== 'nova') readyRes(); }
    else { const go = () => renderAuth(); document.readyState === 'loading' ? document.addEventListener('DOMContentLoaded', go) : go(); }
  });

  /* ---------- dados ---------- */
  const cache = { profile: null, cols: {} }, subs = { profile: [], cols: {} };
  let loaded = null;
  const snapCol = c => ({ docs: [...(cache.cols[c] || new Map()).entries()].map(([id, d]) => ({ id, data: () => d })) });
  const snapProf = () => ({ exists: !!cache.profile, data: () => cache.profile || {} });
  const emitCol = c => (subs.cols[c] || []).forEach(cb => { try { cb(snapCol(c)); } catch (_) {} });
  const emitProf = () => subs.profile.forEach(cb => { try { cb(snapProf()); } catch (_) {} });
  const fail = error => Object.assign(new Error(error?.message || 'erro'), { code: /quota|limit/i.test(error?.message || '') ? 'quota_exceeded' : 'unavailable' });
  async function loadAll() {
    let from = 0;
    for (;;) { const { data, error } = await sb.from('items').select('id,col,data').eq('user_id', uid()).range(from, from + 999); if (error) throw fail(error); data.forEach(r => (cache.cols[r.col] ||= new Map()).set(r.id, r.data)); if (data.length < 1000) break; from += 1000; }
    const { data: p, error: pe } = await sb.from('profiles').select('data').eq('user_id', uid()).maybeSingle(); if (pe) throw fail(pe);
    cache.profile = p ? p.data : null;
    let pn = ''; try { pn = localStorage.getItem('criahub:pendingName') || ''; } catch (_) {}
    pn = pn || session.user.user_metadata?.name || '';
    if (pn && !(cache.profile && cache.profile.name)) { cache.profile = { ...(cache.profile || {}), name: pn }; await sb.from('profiles').upsert({ user_id: uid(), data: cache.profile, updated_at: new Date().toISOString() }); }
    try { localStorage.removeItem('criahub:pendingName'); } catch (_) {}
    sb.channel('criahub-' + uid())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'items', filter: 'user_id=eq.' + uid() }, pl => {
        if (pl.eventType === 'DELETE') { const id = pl.old?.id; for (const c of Object.keys(cache.cols)) if (cache.cols[c].delete(id)) emitCol(c); return; }
        const r = pl.new, m = (cache.cols[r.col] ||= new Map()); if (JSON.stringify(m.get(r.id)) === JSON.stringify(r.data)) return; m.set(r.id, r.data); emitCol(r.col);
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'profiles', filter: 'user_id=eq.' + uid() }, pl => { if (pl.new && JSON.stringify(pl.new.data) !== JSON.stringify(cache.profile)) { cache.profile = pl.new.data; emitProf(); } })
      .subscribe();
  }
  const ensure = () => (loaded ||= loadAll());
  function colRef(c) {
    return {
      onSnapshot(cb, onErr) { (subs.cols[c] ||= []).push(cb); ensure().then(() => cb(snapCol(c)), e => onErr && onErr(e)); return () => {}; },
      doc(id) { return {
        async set(body) { (cache.cols[c] ||= new Map()).set(id, body); const { error } = await sb.from('items').upsert({ id, user_id: uid(), col: c, data: body, updated_at: new Date().toISOString() }); if (error) throw fail(error); },
        async delete() { cache.cols[c]?.delete(id); const { error } = await sb.from('items').delete().eq('id', id).eq('user_id', uid()); if (error) throw fail(error); },
      }; },
    };
  }
  const profRef = {
    onSnapshot(cb, onErr) { subs.profile.push(cb); ensure().then(() => cb(snapProf()), e => onErr && onErr(e)); return () => {}; },
    async set(obj) { cache.profile = obj; const { error } = await sb.from('profiles').upsert({ user_id: uid(), data: obj, updated_at: new Date().toISOString() }); if (error) throw fail(error); },
    collection: colRef,
  };
  /* notícias do Radar (tabela news_days) */
  const newsQ = { orderBy() { return newsQ; }, limit() { return newsQ; }, onSnapshot(cb, onErr) { sb.from('news_days').select('date,data').order('date', { ascending: false }).limit(14).then(({ data, error }) => { if (error) { onErr && onErr(error); return; } cb({ docs: (data || []).map(r => ({ id: r.date, data: () => ({ ...r.data, date: r.date }) })) }); }); return () => {}; } };
  /* cotações (comerciais, AwesomeAPI) */
  let fxP = null;
  const fxLoad = () => (fxP ||= fetch('https://economia.awesomeapi.com.br/json/last/USD-BRL,EUR-BRL').then(r => r.json()).catch(() => ({})));
  const fxRef = k => ({ onSnapshot(cb) { fxLoad().then(j => { const q = j[(k === 'usd' ? 'USD' : 'EUR') + 'BRL']; if (q && +q.ask) cb({ exists: true, data: () => ({ rate: +(+q.ask).toFixed(4), date: String(q.create_date || '').slice(0, 10), kind: 'cotação comercial', note: 'Cotação comercial do dia, atualizada ao abrir o app', source: 'AwesomeAPI' }) }); }); return () => {}; } });
  const empty = { orderBy() { return empty; }, limit() { return empty; }, onSnapshot(cb) { cb({ docs: [] }); return () => {}; } };
  const db = {
    doc(path) { if (/^data\/users\/[^/]+\/profile$/.test(path)) return profRef; const m = /^data\/news\/fx\/(usd|eur)$/.exec(path); if (m) return fxRef(m[1]); return { onSnapshot(cb) { cb({ exists: false, data: () => ({}) }); return () => {}; }, collection: () => empty }; },
    collection(path) { return path === 'data/news/days' ? newsQ : empty; },
  };
  const user = { id: async () => uid(), isOwner: () => true, canEdit: () => true };
  const downloads = { async save({ filename, data }) { const blob = data instanceof Blob ? data : new Blob([data]); const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = filename; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 4000); return { status: 'saved' }; } };
  window.claude = { use: async n => { if (n === 'db' || n === 'user') { await ready; await ensure().catch(() => {}); return n === 'db' ? db : user; } if (n === 'downloads') return downloads; return null; } };

  window.criahubLogout = async () => { await sb.auth.signOut(); location.reload(); };
  window.criahubImport = async j => {
    await ready; await ensure();
    const rows = []; Object.entries(j.data || {}).forEach(([c, a]) => Array.isArray(a) && a.forEach(o => { if (o && o.id) { const { id, ...body } = o; rows.push({ id: String(id), user_id: uid(), col: c, data: body, updated_at: new Date().toISOString() }); } }));
    for (let i = 0; i < rows.length; i += 400) { const { error } = await sb.from('items').upsert(rows.slice(i, i + 400)); if (error) { alert('Não consegui importar tudo: ' + error.message); break; } }
    const prof = { ...(j.profile || {}), ...(cache.profile || {}) }; await sb.from('profiles').upsert({ user_id: uid(), data: prof, updated_at: new Date().toISOString() });
    location.reload();
  };

  /* ---------- instalar como app ---------- */
  let deferred = null;
  window.addEventListener('beforeinstallprompt', e => { e.preventDefault(); deferred = e; });
  window.criahubInstall = async () => { if (!deferred) return false; deferred.prompt(); const r = await deferred.userChoice.catch(() => null); deferred = null; return !!r; };
  if ('serviceWorker' in navigator) window.addEventListener('load', () => navigator.serviceWorker.register('sw.js').catch(() => {}));
})();
