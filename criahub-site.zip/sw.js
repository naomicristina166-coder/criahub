/* Service worker do CriaHub: abre rápido e funciona com internet fraca.
   Dados (Supabase) e cotações sempre vêm da rede. */
const CACHE = 'criahub-v1';
const SHELL = ['./', './index.html', './config.js', './shim.js', './manifest.webmanifest', './icons/icon-192.png', './icons/icon-512.png', './icons/apple-touch-icon.png'];
self.addEventListener('install', e => { e.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL)).then(() => self.skipWaiting())); });
self.addEventListener('activate', e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', e => {
  const r = e.request, u = new URL(r.url);
  if (r.method !== 'GET' || /supabase\.co$|awesomeapi\.com\.br$/.test(u.hostname)) return;
  if (r.mode === 'navigate') { e.respondWith(fetch(r).then(res => { caches.open(CACHE).then(c => c.put('./index.html', res.clone())); return res; }).catch(() => caches.match('./index.html'))); return; }
  e.respondWith(caches.match(r).then(hit => { const net = fetch(r).then(res => { if (res.ok || res.type === 'opaque') caches.open(CACHE).then(c => c.put(r, res.clone())); return res; }).catch(() => hit); return hit || net; }));
});
