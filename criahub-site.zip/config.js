/* Preencha com os dados do seu projeto Supabase (Project Settings > API).
   A chave "publishable" (ou "anon") pode ficar aqui: quem protege os dados é o RLS.
   NUNCA coloque aqui a chave secreta (secret / service_role). */
window.CRIAHUB_CONFIG = {
  url: 'https://dvzfllqcgozecvhodygz.supabase.co',
  key: 'sb_publishable_a-svz0y1Hv6AaeP3J7om9g_Qot6D66F',
};
